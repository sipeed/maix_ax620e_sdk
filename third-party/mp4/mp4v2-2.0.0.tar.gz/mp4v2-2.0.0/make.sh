#!/bin/sh

libc=glibc
arch=arm64

for arg in "$@"
do
  if [[ $arg =~ libc ]]; then
    libc="${arg#*=}"
  elif [[ $arg =~ arch ]]; then
    arch="${arg#*=}"
  fi
done

if [ "${arch}" == "arm32" ]; then
  arch=arm
fi

if ! [[ "${arch}" =~ ^(arm|arm64)$ ]]; then
    echo "Please run with 'arch=(arm/arm64) libc=(glibc/uclibc)'"
    exit
elif ! [[ "${libc}" =~ ^(glibc|uclibc)$ ]]; then
    echo "Please run with 'arch=${arch} libc=(glibc/uclibc)'"
    exit
elif [[ "${arch}" == "arm64" && "${libc}" == "uclibc" ]]; then
    echo "Please run with 'arch=arm64 libc=glibc' for arm64"
    exit
fi

echo "arch=${arch} libc=${libc}"

if [ "${arch}" == "arm" ]; then
  if [ "${libc}" == "glibc" ]; then
    TOOL_CHAIN=arm-linux-gnueabihf-
  elif [ "${libc}" == "uclibc" ]; then
    TOOL_CHAIN=arm-AX620E-linux-uclibcgnueabihf-
  fi
elif [ "${arch}" == "arm64" ]; then
  TOOL_CHAIN=aarch64-none-linux-gnu-
fi

WORK_DIR=$(pwd)
INSTALL_DIR=${WORK_DIR}/build
DEST_LIB_DIR=${WORK_DIR}/../lib/${arch}/${libc}
DEST_INC_DIR=${WORK_DIR}/../include

rm -rf ${INSTALL_DIR}
rm -rf ${DEST_LIB_DIR}
rm -rf ${DEST_INC_DIR}

mkdir -p ${DEST_LIB_DIR}
mkdir -p ${DEST_INC_DIR}

./configure --prefix=${INSTALL_DIR} --host=arm-linux --disable-debug CC=${TOOL_CHAIN}gcc CXX=${TOOL_CHAIN}g++ CXXFLAGS="-Os -DNDEBUG" CFLAGS="-Os -DNDEBUG" --enable-pthread LDFLAGS="-lpthread" enable_util=no

make clean && make -j8 && make install

cp -dfr ${INSTALL_DIR}/lib/* ${DEST_LIB_DIR}
cp -dfr ${INSTALL_DIR}/include/* ${DEST_INC_DIR}

rm -f ${DEST_LIB_DIR}/libmp4.la

if [ -e ${DEST_LIB_DIR}/libmp4.so.*.* ]; then
  ${TOOL_CHAIN}strip ${DEST_LIB_DIR}/libmp4.so.*.*
fi

rm -f ${DEST_LIB_DIR}/libmp4.so
rm -f ${DEST_LIB_DIR}/libmp4.so.2
mv ${DEST_LIB_DIR}/libmp4.so.2.0.0 ${DEST_LIB_DIR}/libmp4.so

# keep
# rm  ${INSTALL_DIR} -rf

make distclean

rm -rf ${INSTALL_DIR}
