/**************************************************************************************************
 *
 * Copyright (c) 2019-2023 Axera Semiconductor (Shanghai) Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor (Shanghai) Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor (Shanghai) Co., Ltd.
 *
 **************************************************************************************************/
#pragma once
#include <string.h>
#include <mutex>
#include <tuple>
#include <stdbool.h>
#include "mp4_base_type.h"

namespace nsmp4 {
class CAXRingBuffer;

class CAXRingElement {
public:
    CAXRingElement() {
        this->pBuf = nullptr;
        this->nSize = 0;
        this->bIFrame = false;
        this->nPts = 0;
        this->nRefCount = 0;
        this->pParent = nullptr;
        this->pHeadBuf = nullptr;
        this->nHeadSize = 0;
    }

    CAXRingElement(MP4_U8* pBuf, MP4_U32 nSize, MP4_U64 u64PTS = 0, bool isIFrame = false, MP4_U8* pHeadBuf = nullptr,
                   MP4_U32 nHeadSize = 0) {
        this->nIndex = -1;
        this->pBuf = pBuf;
        this->nSize = nSize;
        this->nPts = u64PTS;
        this->bIFrame = isIFrame;
        this->nRefCount = 0;
        this->pParent = nullptr;
        this->pHeadBuf = pHeadBuf;
        this->nHeadSize = nHeadSize;
    }

    void CopyFrom(CAXRingElement& element) {
        if (this->pBuf) {
            if (element.pHeadBuf && element.nHeadSize > 0) {
                memcpy(this->pBuf, element.pHeadBuf, element.nHeadSize);
                memcpy(this->pBuf + element.nHeadSize, element.pBuf, element.nSize);
            } else {
                memcpy(this->pBuf, element.pBuf, element.nSize);
            }
        }
        this->nSize = element.nSize;
        this->nPts = element.nPts;
        this->bIFrame = element.bIFrame;

        this->nRefCount = 0;
        this->pParent = nullptr;
    }

    MP4_S32 IncreaseRefCount() {
        return ++nRefCount;
    }

    MP4_S32 DecreaseRefCount(bool bForceClear) {
        if (bForceClear) {
            nRefCount = 0;
        } else {
            --nRefCount;
            if (nRefCount < 0) {
                nRefCount = 0;
            }
        }
        return nRefCount;
    }

    MP4_S32 GetRefCount() {
        return nRefCount;
    }

    MP4_S32 GetIndex() {
        return nIndex;
    }

    MP4_S32 SetIndex(MP4_S32 nIndex) {
        return this->nIndex = nIndex;
    }

    void Clear() {
        this->nSize = 0;
        this->bIFrame = false;
        this->nPts = 0;
        this->nRefCount = 0;
    }

public:
    MP4_U8* pBuf{nullptr};
    MP4_U32 nSize;
    MP4_U64 nPts;
    bool bIFrame;

    MP4_U8* pHeadBuf{nullptr};
    MP4_U32 nHeadSize;

    CAXRingBuffer* pParent{nullptr};

private:
    MP4_S32 nRefCount;
    MP4_S32 nIndex;
};

#define AXRING "RING"

class CAXRingBuffer {
public:
    CAXRingBuffer(MP4_U32 nElementBuffSize, MP4_U32 nElementCount, const char* pszName = nullptr) {
        m_nElementCount = nElementCount;
        m_nElementBuffSize = nElementBuffSize;
        m_pRing = new CAXRingElement[m_nElementCount];
        for (MP4_U32 i = 0; i < m_nElementCount; i++) {
            m_pRing[i].pBuf = new MP4_U8[m_nElementBuffSize];
            memset((void*)m_pRing[i].pBuf, 0x0, m_nElementBuffSize);
            m_pRing[i].nSize = 0;
            m_pRing[i].pParent = this;
            m_pRing[i].SetIndex(i);
        }

        m_nHeader = 0;
        m_nTail = 0;
        m_bHasLost = false;
        m_szName[0] = 0;
        if (pszName && strlen(pszName)) {
            strncpy(m_szName, pszName, sizeof(m_szName) - 1);
            m_szName[sizeof(m_szName) - 1] = '\0';
        }
    }

    ~CAXRingBuffer(void) {
        m_nHeader = 0;
        m_nTail = 0;

        if (nullptr == m_pRing) {
            return;
        }

        m_mutex.lock();
        for (MP4_U32 i = 0; i < m_nElementCount; i++) {
            if (nullptr != m_pRing[i].pBuf) {
                delete[] m_pRing[i].pBuf;
            }
        }
        delete[] m_pRing;
        m_mutex.unlock();
    }

    bool IsFull() {
        std::lock_guard<std::mutex> lck(m_mutex);
        return (m_nTail - m_nHeader) == m_nElementCount ? true : false;
    }

    bool IsEmpty() {
        std::lock_guard<std::mutex> lck(m_mutex);
        return (m_nTail == m_nHeader) ? true : false;
    }

    bool Put(CAXRingElement& element) {
        std::lock_guard<std::mutex> lck(m_mutex);

        if (!m_pRing || (element.nSize + element.nHeadSize) > m_nElementBuffSize) {
            // must not go to here
            if (element.bIFrame) {
                m_bHasLost = true;
            }
            return false;
        }

        if ((m_nTail - m_nHeader) == m_nElementCount) {
            // is full
            if (element.bIFrame) {
                // replace the tail with new I Frame
                MP4_U64 nIndex = (m_nTail - 1) % m_nElementCount;
                MP4_S32 nRefCount = m_pRing[nIndex].GetRefCount();
                if (nRefCount == 0) {
                    m_nTail--;
                    m_bHasLost = false;
                } else {
                    m_bHasLost = true;
                    return false;
                }

            } else {
                m_bHasLost = true;  // mark to lost all behind P Frame
                return false;
            }

        } else {
            if (element.bIFrame) {
                m_bHasLost = false;  // add new I frame
            } else {
                if (m_bHasLost) {
                    // drop this P Frame
                    return false;
                }
            }
        }

        MP4_U64 nIndex = m_nTail % m_nElementCount;
        MP4_S32 nRefCount = m_pRing[nIndex].GetRefCount();
        if (nRefCount != 0) {
            m_bHasLost = true;
            return false;
        }

        m_pRing[nIndex].CopyFrom(element);
        m_pRing[nIndex].IncreaseRefCount();
        m_pRing[nIndex].pParent = this;
        m_nTail++;

        return true;
    }

    CAXRingElement* Get() {
        CAXRingElement* element = nullptr;
        std::lock_guard<std::mutex> lck(m_mutex);
        if (m_nHeader == m_nTail) {
            return element;
        }
        MP4_U64 nIndex = m_nHeader % m_nElementCount;
        m_pRing[nIndex].IncreaseRefCount();
        element = &m_pRing[nIndex];
        return element;
    }

    bool Pop(bool bForce = true) {
        std::lock_guard<std::mutex> lck(m_mutex);
        if (m_nHeader == m_nTail) {
            return false;
        }

        MP4_U64 nIndex = m_nHeader % m_nElementCount;
        m_pRing[nIndex].DecreaseRefCount(bForce);
        m_nHeader++;

        return true;
    }

    void Free(CAXRingElement* ele, bool bForce = false) {
        if (!ele) {
            return;
        }
        std::lock_guard<std::mutex> lck(m_mutex);
        MP4_S32 nIndex = ele->GetIndex();
        if (nIndex >= 0 && nIndex < (MP4_S32)m_nElementCount) {
            m_pRing[nIndex].DecreaseRefCount(bForce);
        }
    }

    void Clear() {
        std::lock_guard<std::mutex> lck(m_mutex);
        if (m_pRing) {
            for (MP4_U32 i = 0; i < m_nElementCount; i++) {
                m_pRing[i].Clear();
            }

            m_nHeader = 0;
            m_nTail = 0;
            m_bHasLost = false;
        }
    }

    MP4_U32 Size() {
        if (m_nTail < m_nHeader) {
            return 0;
        }
        return m_nTail - m_nHeader;
    }

private:
    CAXRingElement* m_pRing;
    MP4_U32 m_nElementCount;
    MP4_U32 m_nElementBuffSize;
    MP4_U64 m_nHeader;
    MP4_U64 m_nTail;
    bool m_bHasLost;
    std::mutex m_mutex;
    char m_szName[64];
};
}
