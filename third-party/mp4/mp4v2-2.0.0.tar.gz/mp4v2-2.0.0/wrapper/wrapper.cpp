#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/vfs.h>
#include <regex>
#include <time.h>
#include <sys/prctl.h>
#include <sys/stat.h>

#include "mp4_base_type.h"
#include "mp4_api.h"
#include "AXRingBuffer.h"
#include "mp4_encoder.h"

#define MP4 "MP4"

using namespace nsmp4;

#define MP4_API extern "C" __attribute__((visibility("default")))

#define MILLION 1000000

#define MP4_DEFAULT_FRAME_RATE (25)
#define MP4_DEFAULT_FILE_SIZE (256) // (268435456)  // 256*1024*1024
#define MP4_DEFAULT_RECORD_FILE_NUM (10)
#define MP4_FORMAT_NAME "mp4"
#define MP4_DEFAULT_SAVED_PATH "./"
#define MP4_FILE_NAME_PATTERN "\\d{4}-\\d{2}-\\d{2}-\\d{2}-\\d{2}-\\d{2}\\."
#define MP4_RECORD_SPACE_RESERVED (134217728)  // 128MB:1024*1024*128
#define MP4_RECORD_SPACE_MARGIN (8388608)      // 8MB:1024*1024*8
#define MP4_HEAD_TAIL_SIZE (262)

#define MP4_DEFAULT_AUDIO_SAMPLERATE 16000
#define MP4_DEFAULT_AUDIO_PERIOD 1024

#define MP4_DEFAULT_VIDEO_RATIO (8)
#define MP4_DEFAULT_VIDEO_DEPTH (5)

#define MP4_DEFAULT_AUDIO_RINGBUFFER (2048)
#define MP4_DEFAULT_AUDIO_DEPTH (5)

#define MAX_NAME_LEN (128)  // Year-Month-Day-Hour-Min-Sec.mp4, eg. 2021-07-12-15-00-00.mp4
#define SECOND_5S (5000)
#define SECOND_15S (15000)

#define SAFE_DELETE_PTR(p) {if(p){delete p;p = nullptr;}}

#define MP4_VIDEO_PROFILE_LEVEL 0x01 // 0x7F
#define MP4_AUDIO_PROFILE_LEVEL 0x02

// H264
#define H264_NAL_IDR 5 // Coded slice of an IDR picture
#define H264_NAL_SPS 7 // Sequence parameter set
#define H264_NAL_PPS 8 // Picture parameter set
#define H264_NAL_AUD 9 // Access unit delimiter

// H265
#define H265_NAL_BLA_W_LP 16
#define H265_NAL_RSV_IRAP 23
#define H265_NAL_VPS 32
#define H265_NAL_SPS 33
#define H265_NAL_PPS 34
#define H265_NAL_AUD 35
#define H265_NAL_SEI_PREFIX 39
#define H265_NAL_SEI_SUFFIX 40

// H266
#define H266_NAL_IDR_W_RADL 7
#define H266_NAL_RSV_IRAP 11
#define H266_NAL_OPI 12
#define H266_NAL_DCI 13
#define H266_NAL_VPS 14
#define H266_NAL_SPS 15
#define H266_NAL_PPS 16
#define H266_NAL_PREFIX_APS 17
#define H266_NAL_SUFFIX_APS 18
#define H266_NAL_PH 19
#define H266_NAL_AUD 20
#define H266_NAL_PREFIX_SEI 23
#define H266_NAL_SUFFIX_SEI 24

struct adtsHeader {
    MP4_U32 syncword;  //12 bit 'FFF'
    MP4_U32 id;        //1 bit  0 for MPEG-4，1 for MPEG-2
    MP4_U32 layer;     //2 bit '00'
    MP4_U32 protectionAbsent;  //1 bit 1: without crc，0: with crc
    MP4_U32 profile;           //1 bit AAC object type
    MP4_U32 samplingFreqIndex; //4 bit samplerate
    MP4_U32 privateBit;        //1 bit
    MP4_U32 channelCfg; //3 bit channel cnts
    MP4_U32 originalCopy;         //1 bit
    MP4_U32 home;                  //1 bit
    MP4_U32 copyrightIdentificationBit;   //1 bit
    MP4_U32 copyrightIdentificationStart; //1 bit
    MP4_U32 aacFrameLength;               //13 bit
    MP4_U32 adtsBufferFullness;           //11 bit
    MP4_U32 numberOfRawDataBlockInFrame; //2 bit
};

static MP4_U32 const samplingFrequencyTable[16] = {
    96000, 88200, 64000, 48000,
    44100, 32000, 24000, 22050,
    16000, 12000, 11025, 8000,
    7350, 0, 0, 0
};

namespace {
int mkdir_recursive(char *path, mode_t mode) {
    struct stat st;
    if (stat(path, &st) == 0) {
        if (S_ISDIR(st.st_mode)) {
            return 0;
        } else {
            return -1;
        }
    }

    if (mkdir(path, mode) == 0) {
        return 0;
    }

    char *separator = strrchr(path, '/');
    if (separator != NULL) {
        *separator = '\0';
        if (mkdir_recursive(path, mode) == 0) {
            *separator = '/';

            if (stat(path, &st) == 0) {
                if (S_ISDIR(st.st_mode)) {
                    return 0;
                } else {
                    return -1;
                }
            }

            if (mkdir(path, mode) == 0) {
                return 0;
            }
        }
    }

    return -1;
}

static MP4_S32 ReadOneNaluFromBuf(const MP4_U8* buffer,
                                         MP4_S32 nBufferSize,
                                         MP4_S32 offSet,
                                         bool bIsH264,
                                         mp4_nalu_unit_t &nalu) {
    MP4_S32 i = offSet;

    while (i < nBufferSize) {
        if (buffer[i++] == 0x00 && buffer[i++] == 0x00 && buffer[i++] == 0x00 && buffer[i++] == 0x01) {
            MP4_S32 pos = i;
            while (pos < nBufferSize) {
                if (buffer[pos++] == 0x00 && buffer[pos++] == 0x00 && buffer[pos++] == 0x00 && buffer[pos++] == 0x01) {
                    break;
                }
            }
            if (pos == nBufferSize) {
                nalu.size = pos - i;
            } else {
                nalu.size = (pos - 4) - i;
            }

            nalu.type = bIsH264 ? (buffer[i] & 0x1F) : (buffer[i] & 0x7E) >> 1;
            nalu.data = (MP4_U8*)&buffer[i];
            return (nalu.size + i - offSet);
        }
    }

    return 0;
}

static MP4_S32 WriteH264Data(mp4_ctx_t &ctx, mp4_info_t &mp4_info, const MP4_U8* data, MP4_S32 bytes, bool iframe, MP4_U64 pts) {
    MP4FileHandle hMp4File = ctx.handle;

    mp4_nalu_unit_t nalu;
    MP4_S32 pos = 0;
    MP4_S32 len = 0;

    while ((len = ReadOneNaluFromBuf(data, bytes, pos, true, nalu)) > 0) {
        if (H264_NAL_SPS == nalu.type) {
            // sps
            if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                ctx.vtrack = MP4AddH264VideoTrack(hMp4File,
                                                    ctx.time_scale,
                                                    ctx.time_scale / mp4_info.video.framerate,
                                                    mp4_info.video.width,   // width
                                                    mp4_info.video.height,  // height
                                                    nalu.data[1],    // sps[1] AVCProfileIndication
                                                    nalu.data[2],   // sps[2] profile_compat
                                                    nalu.data[3],   // sps[3] AVCLevelIndication
                                                    3);  // 4 bytes length before each NAL unit

                if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                    return -1;
                }
            }

            MP4SetVideoProfileLevel(hMp4File, MP4_VIDEO_PROFILE_LEVEL);  //  Simple Profile @ Level 3
            MP4AddH264SequenceParameterSet(hMp4File, ctx.vtrack, nalu.data, nalu.size);
        }
        else if (H264_NAL_PPS == nalu.type) {
            // pps
            MP4AddH264PictureParameterSet(hMp4File, ctx.vtrack, nalu.data, nalu.size);
        }
        else {
            if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                pos += len;
                continue;
            }

            MP4_S32 datalen = nalu.size + 4;
            MP4_U8* data = new MP4_U8[datalen]; // TODO:
            data[0] = nalu.size >> 24;
            data[1] = nalu.size >> 16;
            data[2] = nalu.size >> 8;
            data[3] = nalu.size & 0xff;
            memcpy(data + 4, nalu.data, nalu.size);

            if (!MP4WriteSample(hMp4File,
                                ctx.vtrack,
                                data,
                                datalen,
                                (pts - ctx.vpts) * ctx.time_scale / MILLION,
                                0,
                                iframe)) {
                ctx.vpts = pts;
                delete[] data;
                return -1;
            }

            ctx.vpts = pts;
            delete[] data;
        }

        pos += len;
    }

    return pos;
}

static MP4_S32 WriteH265Data(mp4_ctx_t &ctx, mp4_info_t &mp4_info, const MP4_U8* data, MP4_S32 bytes, bool iframe, MP4_U64 pts)
{
    MP4FileHandle hMp4File = ctx.handle;

    mp4_nalu_unit_t nalu;
    MP4_S32 pos = 0;
    MP4_S32 len = 0;

    while ((len = ReadOneNaluFromBuf(data, bytes, pos, false, nalu)) > 0) {
        if (H265_NAL_VPS == nalu.type) {
            // vps
            if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                ctx.vtrack = MP4AddH265VideoTrack(hMp4File,
                                                    ctx.time_scale,
                                                    ctx.time_scale / mp4_info.video.framerate,
                                                    mp4_info.video.width,     // width
                                                    mp4_info.video.height,    // height
                                                    nalu.data[1],
                                                    nalu.data[2],
                                                    nalu.data[3],
                                                    0xf);

                if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                    return -1;
                }
            }

            MP4AddH265VideoParameterSet(hMp4File, ctx.vtrack, nalu.data, nalu.size);
            MP4SetVideoProfileLevel(hMp4File, MP4_VIDEO_PROFILE_LEVEL); //  Simple Profile @ Level 3
        }
        else if (H265_NAL_SPS == nalu.type) {
            // sps
            MP4AddH265SequenceParameterSet(hMp4File, ctx.vtrack, nalu.data, nalu.size);
        }
        else if (H265_NAL_PPS == nalu.type) {
            // pps
            MP4AddH265PictureParameterSet(hMp4File, ctx.vtrack, nalu.data, nalu.size);
        }
        else {
            if (MP4_INVALID_TRACK_ID == ctx.vtrack) {
                pos += len;
                continue;
            }

            MP4_S32 datalen = nalu.size + 4;
            MP4_U8* data = new MP4_U8[datalen]; // TODO:
            data[0] = nalu.size>>24;
            data[1] = nalu.size>>16;
            data[2] = nalu.size>>8;
            data[3] = nalu.size&0xff;
            memcpy(data+4, nalu.data, nalu.size);

            if (!MP4WriteSample(hMp4File,
                                ctx.vtrack,
                                data,
                                datalen,
                                (pts - ctx.vpts) * ctx.time_scale / MILLION,
                                0,
                                iframe)) {
                ctx.vpts = pts;
                delete[] data;
                return -1;
            }

            delete[] data;
        }

        ctx.vpts = pts;
        pos += len;
    }

    return pos;
}

static MP4_S32 mp4_write_video(mp4_ctx_t &ctx, mp4_info_t &mp4_info, const MP4_U8* data, MP4_S32 bytes, bool iframe, MP4_U64 pts) {
    if (MP4_INVALID_FILE_HANDLE == ctx.handle && !mp4_info.video.enable) {
        return -1;
    }

    if (0 == ctx.vpts || pts <= ctx.vpts) {
        ctx.vpts = pts - MILLION / mp4_info.video.framerate;
    }

    if (MP4_OBJECT_AVC == mp4_info.video.object) {
        return WriteH264Data(ctx, mp4_info, data, bytes, iframe, pts);
    }
    else if (MP4_OBJECT_HEVC == mp4_info.video.object) {
        return WriteH265Data(ctx, mp4_info, data, bytes, iframe, pts);
    }

    return -1;
}

static bool parseAdtsHeader(const MP4_U8* in, MP4_S32 bytes, struct adtsHeader* res) {
    memset(res,0,sizeof(*res));

    if (bytes < 7) {
        return false;
    }

    if ((in[0] == 0xFF)&&((in[1] & 0xF0) == 0xF0)) {
        res->id = ((MP4_U32) in[1] & 0x08) >> 3;
        res->layer = ((MP4_U32) in[1] & 0x06) >> 1;
        res->protectionAbsent = (MP4_U32) in[1] & 0x01;
        res->profile = ((MP4_U32) in[2] & 0xc0) >> 6;
        res->samplingFreqIndex = ((MP4_U32) in[2] & 0x3c) >> 2;
        res->privateBit = ((MP4_U32) in[2] & 0x02) >> 1;
        res->channelCfg = ((((MP4_U32) in[2] & 0x01) << 2) | (((MP4_U32) in[3] & 0xc0) >> 6));
        res->originalCopy = ((MP4_U32) in[3] & 0x20) >> 5;
        res->home = ((MP4_U32) in[3] & 0x10) >> 4;
        res->copyrightIdentificationBit = ((MP4_U32) in[3] & 0x08) >> 3;
        res->copyrightIdentificationStart = (MP4_U32) in[3] & 0x04 >> 2;
        res->aacFrameLength = (((((MP4_U32) in[3]) & 0x03) << 11) |
                                (((MP4_U32)in[4] & 0xFF) << 3) |
                                    ((MP4_U32)in[5] & 0xE0) >> 5) ;
        res->adtsBufferFullness = (((MP4_U32) in[5] & 0x1f) << 6 |
                                        ((MP4_U32) in[6] & 0xfc) >> 2);
        res->numberOfRawDataBlockInFrame = ((MP4_U32) in[6] & 0x03);

        return true;
    }
    else {
        return false;
    }
}

static MP4_S32 WriteAudioData(mp4_ctx_t &ctx, mp4_info_t &mp4_info, const MP4_U8* data, MP4_S32 bytes, MP4_U64 pts)
{
    MP4FileHandle hMp4File = ctx.handle;
    MP4_S32 pos = 0;

    mp4_object_e object = mp4_info.audio.object;

    if (MP4_INVALID_TRACK_ID == ctx.atrack) {
        if (MP4_OBJECT_AAC == object) {
            // parser
            struct adtsHeader header;

            if (!parseAdtsHeader(data, bytes, &header)) {
                return -1;
            }

            MP4_S32 nSampleRate = 0;
            if (header.samplingFreqIndex < 16) {
                nSampleRate = samplingFrequencyTable[header.samplingFreqIndex];
            }

            if (0 != nSampleRate) {
                mp4_info.audio.samplerate = nSampleRate;
            }

            mp4_info.audio.aot = header.profile + 1;
            mp4_info.audio.chncnt = header.channelCfg;

            ctx.atrack = MP4AddAudioTrack(hMp4File, mp4_info.audio.samplerate, MP4_DEFAULT_AUDIO_PERIOD, MP4_MPEG4_AUDIO_TYPE);
        }
        else if (MP4_OBJECT_ALAW == object) {
            ctx.atrack = MP4AddALawAudioTrack(hMp4File, mp4_info.audio.samplerate);
        }
        else if (MP4_OBJECT_ULAW == object) {
            ctx.atrack = MP4AddULawAudioTrack(hMp4File, mp4_info.audio.samplerate);
        }

        MP4SetAudioProfileLevel(hMp4File, MP4_AUDIO_PROFILE_LEVEL);
    }

    if (MP4_INVALID_TRACK_ID == ctx.atrack) {
        return -1;
    }

    if (MP4_OBJECT_AAC == object) {
        MP4_U8 samplingFrequencyIndex = 0;
        MP4_U8 profile = 0;
        MP4_U8 channelConfiguration = 0;

        struct adtsHeader header;

        if (!parseAdtsHeader(data, bytes, &header)) {
            return -1;
        }

        profile = header.profile;
        samplingFrequencyIndex = header.samplingFreqIndex;
        channelConfiguration = header.channelCfg;

        MP4_U8 aacConfig[2] = {0};
        aacConfig[0] = (MP4_U8)(((profile + 1) << 3) | (samplingFrequencyIndex >> 1));
        aacConfig[1] = (MP4_U8)((samplingFrequencyIndex << 7) | (channelConfiguration << 3));

        MP4SetTrackESConfiguration(hMp4File, ctx.atrack, aacConfig, sizeof aacConfig);

        MP4WriteSample(hMp4File, ctx.atrack, &data[7], bytes - 7, (pts - ctx.apts) * mp4_info.audio.samplerate / MILLION, 0, 1);
    }
    else {
        MP4WriteSample(hMp4File, ctx.atrack, &data[0], bytes, (pts - ctx.apts) * mp4_info.audio.samplerate / MILLION, 0, 1);
    }

    pos += bytes;
    ctx.apts = pts;

    return pos;
}

static MP4_S32 mp4_write_audio(mp4_ctx_t &ctx, mp4_info_t &mp4_info, const MP4_U8* data, MP4_S32 bytes, MP4_U64 pts) {
    if (MP4_INVALID_FILE_HANDLE == ctx.handle && !mp4_info.audio.enable) {
        return -1;
    }

    if (0 == ctx.apts || pts <= ctx.apts) {
        ctx.apts = pts - (MP4_DEFAULT_AUDIO_PERIOD * MILLION) / mp4_info.audio.samplerate;
    }

    return WriteAudioData(ctx, mp4_info, data, bytes, pts);
}

static MP4_S32 mp4_create_handle(const mp4_info_t& mp4_info, mp4_ctx_t &ctx) {
    if (mp4_info.video.enable
        && (mp4_info.video.object != MP4_OBJECT_AVC
            && mp4_info.video.object != MP4_OBJECT_HEVC)) {
        return -1;
    }

    if (mp4_info.audio.enable
        && (mp4_info.audio.object != MP4_OBJECT_ALAW
            && mp4_info.audio.object != MP4_OBJECT_ULAW
            && mp4_info.audio.object != MP4_OBJECT_AAC)) {
        return -1;
    }

    MP4FileHandle hMp4file = MP4_INVALID_FILE_HANDLE;

    // create mp4 file
    hMp4file = MP4Create(ctx.file_name.c_str());

    if (MP4_INVALID_FILE_HANDLE == hMp4file) {
        return -1;
    }

    ctx.handle = hMp4file;
    ctx.time_scale = MP4_TIMESCALE;
    ctx.vtrack = MP4_INVALID_TRACK_ID;
    ctx.vpts = 0;
    ctx.atrack = MP4_INVALID_TRACK_ID;
    ctx.apts = 0;

    MP4SetTimeScale(hMp4file, ctx.time_scale);

    return 0;
}

static MP4_S32 mp4_destroy_handle(mp4_ctx_t &ctx) {
    if (ctx.handle) {
        MP4Close(ctx.handle);
        ctx.handle = MP4_INVALID_FILE_HANDLE;
    }

    return 0;
}
}

CMP4Encoder::CMP4Encoder(const mp4_info_t &mp4_info)
: m_stMp4Info(mp4_info) {
    if (0 == m_stMp4Info.max_file_num) {
        m_stMp4Info.max_file_num = MP4_DEFAULT_RECORD_FILE_NUM;
    }

    if (0 == m_stMp4Info.max_file_size) {
        m_stMp4Info.max_file_size = MP4_DEFAULT_FILE_SIZE;
    }

    if (m_stMp4Info.video.enable) {
        if (m_stMp4Info.video.framerate <= 0) {
            m_stMp4Info.video.framerate = MP4_DEFAULT_FRAMERATE;
        }

        if (m_stMp4Info.video.max_frm_size <= 0) {
            m_stMp4Info.video.max_frm_size = m_stMp4Info.video.width * m_stMp4Info.video.height * 3 / 2 / MP4_DEFAULT_VIDEO_RATIO;
        }

        if (m_stMp4Info.video.depth <= 0) {
            m_stMp4Info.video.depth = MP4_DEFAULT_VIDEO_DEPTH;
        }
    }

    if (m_stMp4Info.audio.enable) {
        if (m_stMp4Info.audio.samplerate <= 0) {
            m_stMp4Info.audio.samplerate = MP4_DEFAULT_AUDIO_SAMPLERATE;
        }

        if (m_stMp4Info.audio.max_frm_size <= 0) {
            m_stMp4Info.audio.max_frm_size = MP4_DEFAULT_AUDIO_RINGBUFFER;
        }

        if (m_stMp4Info.audio.depth <= 0) {
            m_stMp4Info.audio.depth = MP4_DEFAULT_AUDIO_DEPTH;
        }
    }
}

bool CMP4Encoder::Start() {
    // init param
    bool ret = InitParam();

    // start thread
    if (ret) {
        std::unique_lock<std::mutex> lck(m_mtxMp4);

        if (0 == m_nMaxFileNum || 0 == m_nMaxFileSize) {
            return false;
        }

        m_bThreadRunning = false;

        m_EventThread = std::thread(&CMP4Encoder::WriteFrameThreadFunc, this);

        // cv wait thread start
        m_cvMp4.wait_for(lck, std::chrono::milliseconds(SECOND_5S), [this]() { return (m_bThreadRunning ? true : false); });

        return m_bThreadRunning ? true : false;
    }

    return ret;
}

bool CMP4Encoder::Stop() {
    {
        std::unique_lock<std::mutex> lck(m_mtxMp4);
        m_bThreadRunning = false;
        m_cvMp4.notify_all();
    }

    if (m_EventThread.joinable()) {
        m_EventThread.join();
    }

    DropFrames();

    return true;
}

MP4_VOID* CMP4Encoder::WriteFrameThreadFunc() {
    prctl(PR_SET_NAME, "MP4_Write");

    MP4_U64 nMaxFileSize = 0;
    std::string strFullName;

    {
        std::unique_lock<std::mutex> lck(m_mtxMp4);
        m_bThreadRunning = true;
        m_cvMp4.notify_all();
    }

    nMaxFileSize = m_nMaxFileSize;
    bool bMp4Failure = false;
    while (m_bThreadRunning) {
        if (!m_bLoopCoverRecord && (m_sMp4RecordFiles.size() >= m_nMaxFileNum)) {
            break;
        }

        MP4_U64 nVIndex = 0;
        MP4_U64 nAIndex = 0;
        MP4_U64 nTotalSize = 0;
        MP4_CHAR szFileName[MAX_NAME_LEN] = {0};
        MP4_U64 nCurrAvailSpace = GetAvailableSpace();

        // gen file name
        GenFileName(szFileName, MAX_NAME_LEN);

        strFullName = m_sMp4Path + szFileName;

        if ((m_sMp4RecordFiles.size() >= m_nMaxFileNum) || (nCurrAvailSpace < nMaxFileSize)) {
            if (!RemoveFilesForSpace(nCurrAvailSpace)) {
                if (m_stMp4Info.sr_callback) {
                    m_stMp4Info.sr_callback(this, nullptr, MP4_STATUS_DISK_FULL, m_stMp4Info.user_data);
                }

                bMp4Failure = true;
                break;
            }
        }

        m_sMp4RecordFiles.insert(std::make_pair(strFullName, nMaxFileSize));

        // create handle
        mp4_ctx_t ctx;
        ctx.file_name = strFullName;
        if (0 != mp4_create_handle(m_stMp4Info, ctx)) {
            bMp4Failure = true;
            break;
        }

        // start
        if (m_stMp4Info.sr_callback) {
            m_stMp4Info.sr_callback(this, ctx.file_name.c_str(), MP4_STATUS_START, m_stMp4Info.user_data);
        }

        bool bVDataValid = false;

        while (m_bThreadRunning) {
            MP4_S32 nSize = 0;
            bool bVEmpty = true;
            bool bAEmpty = true;
            CAXRingElement* pElement = nullptr;
            auto pVRingBufFrame = m_pRingBufRawFrame[MP4_DATA_VIDEO];

            bMp4Failure = false;

            if (pVRingBufFrame) {
                pElement = pVRingBufFrame->Get();
                if (!pElement) {
                    goto AUDIO_TRACK;
                }

                bVEmpty = false;
                bVDataValid = true;

                if (nTotalSize >= nMaxFileSize && pElement->bIFrame) {
                    break;
                }

                if ((nSize = mp4_write_video(ctx, m_stMp4Info,  pElement->pBuf, pElement->nSize, (bool)pElement->bIFrame, pElement->nPts)) < 0) {
                    bMp4Failure = true;
                    break;
                }

                ++ nVIndex;
                nTotalSize += nSize;
                pVRingBufFrame->Pop();
            }
            else {
                bVDataValid = true;
            }

AUDIO_TRACK:
            auto pARingBufFrame = m_pRingBufRawFrame[MP4_DATA_AUDIO];
            if (pARingBufFrame) {
                pElement = pARingBufFrame->Get();
                if (!pElement) {
                    goto NEXT_LOOP;
                }

                bAEmpty = false;

                if (!bVDataValid) {
                    // drop audio frame
                    if (pARingBufFrame->Size() > 1) {
                        pARingBufFrame->Pop();
                    }
                    bAEmpty = true;
                    goto NEXT_LOOP;
                }

                if ((nSize = mp4_write_audio(ctx, m_stMp4Info, pElement->pBuf, pElement->nSize, pElement->nPts)) < 0) {
                    bMp4Failure = true;
                    break;
                }

                ++ nAIndex;
                nTotalSize += nSize;
                pARingBufFrame->Pop();
            }

NEXT_LOOP:
            if (bVEmpty && bAEmpty) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;
            }
        }

        SetRecordFileSizeInfo(strFullName, nTotalSize + MP4_HEAD_TAIL_SIZE);
        mp4_destroy_handle(ctx);

        // complete
        if (m_stMp4Info.sr_callback) {
            m_stMp4Info.sr_callback(this, ctx.file_name.c_str(), bMp4Failure ? MP4_STATUS_FAILURE : MP4_STATUS_COMPLETE, m_stMp4Info.user_data);
        }
    }

    if (bMp4Failure) {
        if (m_stMp4Info.sr_callback) {
            m_stMp4Info.sr_callback(this, nullptr, MP4_STATUS_FAILURE, m_stMp4Info.user_data);
        }
    }

    return nullptr;
}

bool CMP4Encoder::SendVideoFrame(const MP4_VOID* data, MP4_U32 size, MP4_U64 nPts /*=0*/, bool bIFrame /*=false*/) {
    if (!m_bThreadRunning || !m_pRingBufRawFrame[MP4_DATA_VIDEO]) {
        return false;
    }

    CAXRingElement ele((MP4_U8*)data, size, nPts, bIFrame);
    m_pRingBufRawFrame[MP4_DATA_VIDEO]->Put(ele);

    return true;
}

bool CMP4Encoder::SendAudioFrame(const MP4_VOID* data, MP4_U32 size, MP4_U64 nPts /*=0*/) {
    if (!m_bThreadRunning || !m_pRingBufRawFrame[MP4_DATA_AUDIO]) {
        return false;
    }

    CAXRingElement ele((MP4_U8*)data, size, nPts, true);
    m_pRingBufRawFrame[MP4_DATA_AUDIO]->Put(ele);

    return true;
}

bool CMP4Encoder::InitParam() {
    MP4_U64 nRecordFilesSize = 0;
    MP4_U32 nVRingbufSize = 0;
    MP4_U32 nARingbufSize = 0;

    // dest path
    if (m_stMp4Info.dest_path) {
        m_sMp4Path = m_stMp4Info.dest_path;
    }

    m_nMaxFileNum = m_stMp4Info.max_file_num;
    m_nMaxFileSize = m_stMp4Info.max_file_size * 1024 * 1024;

    if (m_sMp4Path[m_sMp4Path.length() - 1] != '/') {
        m_sMp4Path += '/';
    }

    m_bLoopCoverRecord = m_stMp4Info.loop;

    // Make sure mp4 saved path exist
    if (access(m_sMp4Path.c_str(), 0) != 0) {                               // path not exist, try making dir
        char path[128] = {0};
        snprintf(path, 127, "%s", m_sMp4Path.c_str());
        if (mkdir_recursive(path, S_IRWXU | S_IRWXG | S_IRWXO) != 0) {  // mkdir fail, exit
            return false;
        }
    }

    std::string sMp4NamePattern{""};
    if (m_stMp4Info.file_name_prefix) {
        m_sMp4NamePrefix = m_stMp4Info.file_name_prefix;
        sMp4NamePattern = m_stMp4Info.file_name_prefix;
        sMp4NamePattern += MP4_FILE_NAME_PATTERN;
    } else {
        sMp4NamePattern = MP4_FILE_NAME_PATTERN;
    }

    sMp4NamePattern += MP4_FORMAT_NAME;

    m_sMp4RecordFiles = GetRecorderFiles(m_sMp4Path, sMp4NamePattern, nRecordFilesSize);
    m_nFreeSpace = GetFreeSpaceForMp4Record(m_sMp4Path, nRecordFilesSize);

    nVRingbufSize = m_stMp4Info.video.max_frm_size;
    nARingbufSize = m_stMp4Info.audio.max_frm_size;

    if (m_stMp4Info.video.enable) {
        m_pRingBufRawFrame[MP4_DATA_VIDEO] = new CAXRingBuffer(nVRingbufSize, m_stMp4Info.video.depth, MP4 "_VIDEO");
    }

    if (m_stMp4Info.audio.enable) {
        m_pRingBufRawFrame[MP4_DATA_AUDIO] = new CAXRingBuffer(nARingbufSize, m_stMp4Info.audio.depth, MP4 "_AUDIO");
    }

    return true;
}

MP4_VOID CMP4Encoder::GenFileName(MP4_CHAR* szFileName, MP4_S32 FileNameLen) {
    time_t rawtime;
    struct tm* ptminfo;
    time(&rawtime);
    ptminfo = localtime(&rawtime);

    {
        std::unique_lock<std::mutex> lck(m_mtxMp4);
        snprintf((char*)szFileName, FileNameLen, "%s%04d-%02d-%02d-%02d-%02d-%02d.%s", m_sMp4NamePrefix.c_str(), ptminfo->tm_year + 1900,
                 ptminfo->tm_mon + 1, ptminfo->tm_mday, ptminfo->tm_hour, ptminfo->tm_min, ptminfo->tm_sec, MP4_FORMAT_NAME);
    }
}

std::map<std::string, MP4_U64> CMP4Encoder::GetRecorderFiles(std::string path, std::string suffix, MP4_U64& totalSize) {
    std::map<std::string, MP4_U64> files;
    DIR* dp = nullptr;
    struct dirent* dirp;
    struct stat stStat;
    totalSize = 0;

    if ((dp = opendir(path.c_str())) == nullptr) {
        return files;
    }

    std::regex reg_obj(suffix);
    while ((dirp = readdir(dp)) != nullptr) {
        if (dirp->d_type == 8) {
            // 4 means catalog; 8 means file; 0 means unknown
            if (regex_match(dirp->d_name, reg_obj)) {
                std::string all_path = path + dirp->d_name;
                stat(all_path.c_str(), &stStat);
                if (stStat.st_size <= 0) {  // remove empty file
                    remove(all_path.c_str());
                } else {
                    totalSize += stStat.st_size;
                    files.insert(std::make_pair(all_path, stStat.st_size));
                }
            }
        }
    }

    closedir(dp);

    return files;
}

MP4_U64 CMP4Encoder::GetFreeSpaceForMp4Record(const std::string& path, const MP4_U64 nRecordFilesSize) {
    struct statfs diskInfo = {0};
    MP4_U64 nBlockSize = 0;
    MP4_U64 nFreeSpace = 0;

    if (statfs(path.c_str(), &diskInfo)) {
        return 0;
    }

    nBlockSize = diskInfo.f_bsize;
    nFreeSpace = diskInfo.f_bfree * nBlockSize;

    return (nFreeSpace + nRecordFilesSize > MP4_RECORD_SPACE_RESERVED) ? (nFreeSpace + nRecordFilesSize - MP4_RECORD_SPACE_RESERVED) : 0;
}

MP4_U64 CMP4Encoder::GetAvailableSpace() {
    MP4_U64 nTotalFileSize = 0;
    MP4_U64 nAvailSize = 0;
    for (auto& file : m_sMp4RecordFiles) {
        nTotalFileSize += file.second;
    }

    nAvailSize = m_nFreeSpace - nTotalFileSize + MP4_RECORD_SPACE_MARGIN;

    return nAvailSize;
}

bool CMP4Encoder::RemoveFilesForSpace(const MP4_U64& nCurrAvailableSpace) {
    if (m_sMp4RecordFiles.empty()) {
        return false;
    }

    MP4_U64 nAvailSize = nCurrAvailableSpace;
    while (!m_sMp4RecordFiles.empty()) {
        if (remove(m_sMp4RecordFiles.begin()->first.c_str())) {
            return false;
        }

        // deleted
        if (m_stMp4Info.sr_callback) {
            m_stMp4Info.sr_callback(this, m_sMp4RecordFiles.begin()->first.c_str(), MP4_STATUS_DELETED, m_stMp4Info.user_data);
        }

        nAvailSize += m_sMp4RecordFiles.begin()->second;
        m_sMp4RecordFiles.erase(m_sMp4RecordFiles.begin());

        if (nAvailSize >= m_nMaxFileSize && (m_sMp4RecordFiles.size() < m_nMaxFileNum)) {
            break;
        }
    }

    return true;
}

MP4_VOID CMP4Encoder::DropFrames() {
    for (int i = 0; i < MP4_DATA_BUTT; i++) {
        if (m_pRingBufRawFrame[i]) {
            CAXRingElement* pEle = nullptr;
            do {
                pEle = m_pRingBufRawFrame[i]->Get();
                if (!pEle) {
                    break;
                }

                m_pRingBufRawFrame[i]->Pop();

            } while (pEle);
        }
    }
}

MP4_VOID CMP4Encoder::SetRecordFileSizeInfo(const std::string& strFileName, const MP4_U64& nFileSize) {
    std::map<std::string, MP4_U64>::iterator iter;

    iter = m_sMp4RecordFiles.find(strFileName);

    if (iter != m_sMp4RecordFiles.end()) {
        iter->second = nFileSize;
    }
}

CMP4Encoder::~CMP4Encoder() {
    for (int i = 0; i < MP4_DATA_BUTT; i++) {
        SAFE_DELETE_PTR(m_pRingBufRawFrame[i]);
    }
}

MP4_API MP4_HANDLE mp4_create(const mp4_info_t* mp4_info) {
    if (!mp4_info) {
        return nullptr;
    }

    if (mp4_info->video.enable) {
        if (mp4_info->video.object != MP4_OBJECT_AVC
            && mp4_info->video.object != MP4_OBJECT_HEVC) {
            return nullptr;
        }
        if (mp4_info->video.width == 0
            || mp4_info->video.height == 0) {
            return nullptr;
        }
    }

    if (mp4_info->audio.enable) {
        if (mp4_info->audio.object != MP4_OBJECT_ALAW
            && mp4_info->audio.object != MP4_OBJECT_ULAW
            && mp4_info->audio.object != MP4_OBJECT_AAC) {
            return nullptr;
        }
    }

    CMP4Encoder *inst = new CMP4Encoder(*mp4_info);

    if (!inst) {
        return nullptr;
    }

    if (!inst->Start()) {
        delete inst;

        return nullptr;
    }

    return (MP4_HANDLE)inst;
}

MP4_API MP4_S32 mp4_destroy(MP4_HANDLE handle) {
    if (!handle) {
        return - 1;
    }

    CMP4Encoder *inst = (CMP4Encoder *)handle;

    inst->Stop();

    delete inst;

    return 0;
}

MP4_API MP4_S32 mp4_send(MP4_HANDLE handle, mp4_data_e type, const MP4_VOID* data, MP4_S32 bytes, MP4_U64 pts, bool iframe) {
    if (!handle || !data || (0 == bytes)) {
        return - 1;
    }

    if (0 == pts) {
        pts = time(nullptr);
    }

    CMP4Encoder *inst = (CMP4Encoder *)handle;

    if (MP4_DATA_VIDEO == type) {
        return inst->SendVideoFrame(data, bytes, pts, iframe);
    }
    else if (MP4_DATA_AUDIO == type) {
        return inst->SendAudioFrame(data, bytes, pts);
    }

    return -1;
}
