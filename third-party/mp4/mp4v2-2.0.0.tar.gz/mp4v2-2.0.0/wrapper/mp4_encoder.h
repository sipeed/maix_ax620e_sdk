/**************************************************************************************************
 *
 * Copyright (c) 2019-2023 Axera Semiconductor (Shanghai) Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor (Shanghai) Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor (Shanghai) Co., Ltd.
 *
 **************************************************************************************************/

#pragma once
#include <sys/time.h>
#include <map>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <functional>
#include <dirent.h>
#include "mp4_base_type.h"
#include "AXRingBuffer.h"
#include "mp4_api.h"
#include "include/mp4v2/mp4v2.h"
#include "include/mp4v2/platform.h"

using namespace nsmp4;

#define MP4_DEFAULT_FRAMERATE 25
#define MP4_TIMESCALE 90000

typedef struct _mp4_nalu_unit_t {
    MP4_S32 type;
    MP4_S32  size;
    MP4_U8* data;
} mp4_nalu_unit_t;

typedef struct _mp4_ctx_t {
    std::string file_name;

    MP4_S32 time_scale;

    MP4TrackId vtrack;
    MP4_U64 vpts;

    MP4TrackId atrack;
    MP4_U64 apts;

    MP4FileHandle handle;

    _mp4_ctx_t() {
        time_scale = MP4_TIMESCALE;
        vtrack = MP4_INVALID_TRACK_ID;
        vpts = 0;
        atrack = MP4_INVALID_TRACK_ID;
        apts = 0;
        handle = MP4_INVALID_FILE_HANDLE;
    }
} mp4_ctx_t;

class CMP4Encoder {
public:
    CMP4Encoder(const mp4_info_t &mp4_info);
    virtual ~CMP4Encoder();

    bool Start();
    bool Stop();
    bool SendVideoFrame(const MP4_VOID* data, MP4_U32 size, MP4_U64 nPts = 0, bool bIFrame = false);
    bool SendAudioFrame(const MP4_VOID* data, MP4_U32 size, MP4_U64 nPts = 0);

private:
    bool InitParam();
    MP4_VOID GenFileName(MP4_CHAR* szFileName, MP4_S32 FileNameLen);
    std::map<std::string, MP4_U64> GetRecorderFiles(std::string path, std::string suffix, MP4_U64& totalSize);
    MP4_U64 GetFreeSpaceForMp4Record(const std::string& path, const MP4_U64 nRecordFilesSize);
    MP4_U64 GetAvailableSpace();
    bool RemoveFilesForSpace(const MP4_U64& nCurrAvailableSpace);
    MP4_VOID DropFrames();
    MP4_VOID SetRecordFileSizeInfo(const std::string& strFileName, const MP4_U64& nFileSize);

    MP4_VOID* WriteFrameThreadFunc();

public:
    CAXRingBuffer* m_pRingBufRawFrame[MP4_DATA_BUTT]{0};
    mp4_info_t m_stMp4Info;
    bool m_bThreadRunning{false};
    bool m_bLoopCoverRecord{true};
    MP4_U32 m_nFrameRate{0};
    MP4_U32 m_nMaxFileNum{0};
    MP4_U32 m_nMaxFileSize{0};
    MP4_U64 m_nFreeSpace{0};

    std::string m_sMp4Path{"./"};
    std::string m_sMp4NamePrefix{""};
    std::map<std::string, MP4_U64> m_sMp4RecordFiles;

    std::mutex m_mtxMp4;
    std::condition_variable m_cvMp4;

    std::thread m_EventThread;
};
