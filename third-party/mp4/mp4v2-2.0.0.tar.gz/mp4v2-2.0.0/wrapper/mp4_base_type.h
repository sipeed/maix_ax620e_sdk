/**************************************************************************************************
 *
 * Copyright (c) 2019-2023 Axera Semiconductor (Shanghai) Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor (Shanghai) Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor (Shanghai) Co., Ltd.
 *
 **************************************************************************************************/

#ifndef _MP4_BASE_TYPE_H_
#define _MP4_BASE_TYPE_H_

/* types of variables typedef */
typedef unsigned long long int  MP4_U64;
typedef unsigned int            MP4_U32;
typedef unsigned short          MP4_U16;
typedef unsigned char           MP4_U8;
typedef long long int           MP4_S64;
typedef int                     MP4_S32;
typedef short                   MP4_S16;
typedef signed char             MP4_S8;
typedef char                    MP4_CHAR;
typedef long                    MP4_LONG;
typedef unsigned long           MP4_ULONG;
typedef unsigned long           MP4_ADDR;
typedef float                   MP4_F32;
typedef double                  MP4_F64;
typedef void                    MP4_VOID;
typedef unsigned int            MP4_SIZE_T;

#ifndef MP4_NULL
#if defined(__cplusplus)
#define MP4_NULL 0
#else
#define MP4_NULL ((void *)0)
#endif
#endif

#endif //_MP4_BASE_TYPE_H_
